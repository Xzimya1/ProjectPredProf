import sqlite3
from werkzeug.security import generate_password_hash

def init_db():
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()

    # Таблица пользователей
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('admin', 'user'))
        )
    ''')

    # Таблица инвентаря
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('new', 'used', 'broken'))
        )
    ''')

    # Таблица заявок
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            item_id INTEGER NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('pending', 'approved', 'rejected')),
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (item_id) REFERENCES inventory(id)
        )
    ''')

    # Таблица планов закупок
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS purchase_plans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_name TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            price REAL NOT NULL,
            supplier TEXT NOT NULL
        )
    ''')

    # Добавляем администратора, если его нет
    admin_username = 'admin'
    admin_password = generate_password_hash('admin123')  # Хешируем пароль
    cursor.execute('SELECT * FROM users WHERE username = ?', (admin_username,))
    if not cursor.fetchone():
        cursor.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
                       (admin_username, admin_password, 'admin'))

    conn.commit()
    conn.close()

# Инициализация базы данных
init_db()