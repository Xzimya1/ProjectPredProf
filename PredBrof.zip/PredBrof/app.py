from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Главная страница
@app.route('/')
def index():
    if 'username' in session:
        if session['role'] == 'admin':
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('user_dashboard'))
    return redirect(url_for('login'))

# Авторизация
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = sqlite3.connect('inventory.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
        user = cursor.fetchone()
        conn.close()

        if user and check_password_hash(user[2], password):
            session['username'] = user[1]
            session['role'] = user[3]
            session['user_id'] = user[0]  # Сохраняем ID пользователя в сессии
            return redirect(url_for('index'))
        else:
            flash('Неверное имя пользователя или пароль')
    return render_template('login.html')

# Регистрация
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'])
        role = 'user'  # По умолчанию регистрируем как пользователя

        conn = sqlite3.connect('inventory.db')
        cursor = conn.cursor()
        cursor.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', (username, password, role))
        conn.commit()

        # Получаем ID нового пользователя
        cursor.execute('SELECT id FROM users WHERE username = ?', (username,))
        user_id = cursor.fetchone()[0]
        conn.close()

        # Сохраняем данные в сессии
        session['username'] = username
        session['role'] = role
        session['user_id'] = user_id  # Сохраняем ID пользователя в сессии

        flash('Регистрация прошла успешно!')
        return redirect(url_for('index'))
    return render_template('register.html')

# Выход
@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('role', None)
    session.pop('user_id', None)
    return redirect(url_for('index'))

# Панель администратора
@app.route('/admin')
def admin_dashboard():
    if 'username' in session and session['role'] == 'admin':
        conn = sqlite3.connect('inventory.db')
        cursor = conn.cursor()

        # Получаем инвентарь
        cursor.execute('SELECT * FROM inventory')
        inventory = cursor.fetchall()

        # Получаем заявки
        cursor.execute('''
            SELECT requests.id, users.username, inventory.name, requests.status 
            FROM requests 
            JOIN users ON requests.user_id = users.id 
            JOIN inventory ON requests.item_id = inventory.id
        ''')
        requests = cursor.fetchall()

        # Получаем планы закупок
        cursor.execute('SELECT * FROM purchase_plans')
        purchase_plans = cursor.fetchall()

        conn.close()
        return render_template('admin.html', inventory=inventory, requests=requests, purchase_plans=purchase_plans)
    return redirect(url_for('login'))

# Панель пользователя
@app.route('/user')
def user_dashboard():
    if 'username' in session and session['role'] == 'user' and 'user_id' in session:
        conn = sqlite3.connect('inventory.db')
        cursor = conn.cursor()

        # Получаем доступный инвентарь
        cursor.execute('SELECT * FROM inventory')
        inventory = cursor.fetchall()

        # Получаем заявки пользователя
        cursor.execute('''
            SELECT requests.id, inventory.name, requests.status 
            FROM requests 
            JOIN inventory ON requests.item_id = inventory.id 
            WHERE requests.user_id = ?
        ''', (session['user_id'],))
        requests = cursor.fetchall()

        conn.close()
        return render_template('user.html', inventory=inventory, requests=requests)
    return redirect(url_for('login'))

# Добавление инвентаря (админ)
@app.route('/add_item', methods=['POST'])
def add_item():
    if 'username' in session and session['role'] == 'admin':
        name = request.form['name']
        quantity = request.form['quantity']
        status = request.form['status']

        conn = sqlite3.connect('inventory.db')
        cursor = conn.cursor()
        cursor.execute('INSERT INTO inventory (name, quantity, status) VALUES (?, ?, ?)', (name, quantity, status))
        conn.commit()
        conn.close()

        flash('Инвентарь добавлен')
        return redirect(url_for('admin_dashboard'))
    return redirect(url_for('login'))

# Создание заявки на получение инвентаря (пользователь)
@app.route('/request_item', methods=['POST'])
def request_item():
    if 'username' in session and session['role'] == 'user' and 'user_id' in session:
        item_id = request.form['item_id']

        conn = sqlite3.connect('inventory.db')
        cursor = conn.cursor()

        # Проверяем, есть ли предмет в инвентаре
        cursor.execute('SELECT * FROM inventory WHERE id = ?', (item_id,))
        item = cursor.fetchone()

        if item:
            # Создаем заявку
            cursor.execute('INSERT INTO requests (user_id, item_id, status) VALUES (?, ?, ?)',
                           (session['user_id'], item_id, 'pending'))
            conn.commit()
            flash('Заявка успешно создана')
        else:
            flash('Предмет не найден')

        conn.close()
        return redirect(url_for('user_dashboard'))
    return redirect(url_for('login'))

# Одобрение заявки (админ)
@app.route('/approve_request/<int:id>')
def approve_request(id):
    if 'username' in session and session['role'] == 'admin':
        conn = sqlite3.connect('inventory.db')
        cursor = conn.cursor()
        cursor.execute('UPDATE requests SET status = "approved" WHERE id = ?', (id,))
        conn.commit()
        conn.close()
        flash('Заявка одобрена')
    return redirect(url_for('admin_dashboard'))

# Отклонение заявки (админ)
@app.route('/reject_request/<int:id>')
def reject_request(id):
    if 'username' in session and session['role'] == 'admin':
        conn = sqlite3.connect('inventory.db')
        cursor = conn.cursor()
        cursor.execute('UPDATE requests SET status = "rejected" WHERE id = ?', (id,))
        conn.commit()
        conn.close()
        flash('Заявка отклонена')
    return redirect(url_for('admin_dashboard'))

# Добавление плана закупок (админ)
@app.route('/add_purchase_plan', methods=['POST'])
def add_purchase_plan():
    if 'username' in session and session['role'] == 'admin':
        item_name = request.form['item_name']
        quantity = request.form['quantity']
        price = request.form['price']
        supplier = request.form['supplier']

        conn = sqlite3.connect('inventory.db')
        cursor = conn.cursor()
        cursor.execute('INSERT INTO purchase_plans (item_name, quantity, price, supplier) VALUES (?, ?, ?, ?)',
                       (item_name, quantity, price, supplier))
        conn.commit()
        conn.close()

        flash('План закупок добавлен')
        return redirect(url_for('admin_dashboard'))
    return redirect(url_for('login'))

# Отчеты (админ)
@app.route('/reports')
def reports():
    if 'username' in session and session['role'] == 'admin':
        conn = sqlite3.connect('inventory.db')
        cursor = conn.cursor()

        # Получаем список всех заявок
        cursor.execute('''
            SELECT users.username, inventory.name, requests.status 
            FROM requests 
            JOIN users ON requests.user_id = users.id 
            JOIN inventory ON requests.item_id = inventory.id
        ''')
        requests = cursor.fetchall()

        # Получаем список инвентаря
        cursor.execute('SELECT * FROM inventory')
        inventory = cursor.fetchall()

        # Получаем планы закупок
        cursor.execute('SELECT * FROM purchase_plans')
        purchase_plans = cursor.fetchall()

        conn.close()
        return render_template('reports.html', requests=requests, inventory=inventory, purchase_plans=purchase_plans)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)